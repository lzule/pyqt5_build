VS_DOTNET_REFERENCES_COPY_LOCAL
-------------------------------

.. versionadded:: 3.8

Sets the **Copy Local** property for all .NET hint references in the target

Boolean property to enable/disable copying of .NET hint references to
output directory. The default is ``ON``.
