SUFFIX
------

What comes after the target name.

A target property that can be set to override the suffix (such as
``.so`` or ``.exe``) on the name of a library, module or executable.
