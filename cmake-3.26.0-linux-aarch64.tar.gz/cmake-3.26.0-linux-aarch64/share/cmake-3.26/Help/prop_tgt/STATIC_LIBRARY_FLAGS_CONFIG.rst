STATIC_LIBRARY_FLAGS_<CONFIG>
-----------------------------

Per-configuration archiver (or MSVC librarian) flags for a static library
target.

This is the configuration-specific version of :prop_tgt:`STATIC_LIBRARY_FLAGS`.

.. note::

  This property has been superseded by :prop_tgt:`STATIC_LIBRARY_OPTIONS`
  property.
