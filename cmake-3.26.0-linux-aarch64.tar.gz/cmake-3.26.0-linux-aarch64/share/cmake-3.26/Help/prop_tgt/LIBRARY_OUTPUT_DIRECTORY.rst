LIBRARY_OUTPUT_DIRECTORY
------------------------

.. |XXX| replace:: :ref:`LIBRARY <Library Output Artifacts>`
.. |xxx| replace:: library
.. |CMAKE_XXX_OUTPUT_DIRECTORY| replace:: :variable:`CMAKE_LIBRARY_OUTPUT_DIRECTORY`
.. include:: XXX_OUTPUT_DIRECTORY.txt

See also the :prop_tgt:`LIBRARY_OUTPUT_DIRECTORY_<CONFIG>` target property.
